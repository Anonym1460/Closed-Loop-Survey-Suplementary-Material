"""Prepare a local audit directory using SHA-256 identity, without changing originals.
Usage: python prepare_audit_sources.py SOURCE_DIRECTORY [SOURCE_DIRECTORY ...] --output CANONICAL_DIRECTORY
The manifest defines required versions. Source PDFs are not supplied with the supplement.
"""
from pathlib import Path
import argparse,csv,hashlib,shutil

def main():
 ap=argparse.ArgumentParser();ap.add_argument('roots',type=Path,nargs='+');ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 rows=list(csv.DictReader((Path(__file__).parent/'source_manifest.csv').open(encoding='utf-8-sig')))
 expected={r['sha256']:r['source_file'] for r in rows if r['audit_full_text']=='True'};found={}
 for root in args.roots:
  for p in root.rglob('*.pdf'):
   h=hashlib.sha256(p.read_bytes()).hexdigest()
   if h in expected and h not in found:found[h]=p
 args.output.mkdir(parents=True,exist_ok=True)
 for h,src in found.items():
  dest=args.output/expected[h]
  if dest.exists():
   if hashlib.sha256(dest.read_bytes()).hexdigest()!=h:raise ValueError('Different file already exists: '+dest.name)
  elif src.resolve()!=dest.resolve():shutil.copy2(src,dest)
 missing=[name for h,name in expected.items() if h not in found]
 print(f'Matched {len(found)}/{len(expected)} required PDF versions.')
 if missing:print('Not found: '+', '.join(sorted(missing)));raise SystemExit(1)
if __name__=='__main__':main()

# Interpretation of the preliminary search records

These records preserve the historical prioritization stage. They are not a completed systematic eligibility-screening flow and must not be used to infer exhaustive inclusion or exclusion counts.

- The original master ledger has 3,575 normalized bibliographic keys. Its field `final_crosscheck_status` is a legacy field name for archived triage labels, not a claim that every record received final full-text eligibility assessment.
- The original manual file contains 105 records reviewed for priority or possible eligibility. Its 75 `primary_add_candidate` / `contextual_add_candidate` labels were proposals. Of these 75, 16 were subsequently included, two had citation proposals that were not implemented, and 57 did not complete final eligibility assessment. The other 30 retain their recorded historical no-add decisions.
- Of the 73 records deferred to the recent update, one was subsequently included and 72 did not complete final eligibility assessment.
- Consequently, 129 records across these two non-overlapping groups lack completed final eligibility assessment. They remain unevaluated at that stage; no reasons for scientific exclusion are imputed to them. The other master-ledger categories remain archived triage categories, not validated full-text exclusion counts.
- `status_reconciliation_2026-09-23.csv` maps these 178 records to their documented status using available DOI or normalized-title matches. It is a documentary reconciliation, not a new literature assessment.
- `candidate_proposals_2026-09-16_original.csv` preserves the original 30-row file without alteration. Its five historical `cite_only` labels were citation proposals that were not implemented. Their current status is recorded in `citation_proposals_not_implemented.csv`; none is represented as a completed citation or a justified scientific exclusion.
- The authoritative inclusion file is the root-level `supplementary_screening_decisions_2026-09-16.csv`. It contains only the 25 implemented additions. Its date identifies the search round; this clarification does not retrospectively create decisions on that date.

This supplementary cross-check supported selective extension of a survey-seeded, design-oriented corpus. Neither these records nor the added papers establish comprehensive retrieval, exhaustive screening, or absence of other relevant studies. No new corpus records, citations, or scientific exclusion decisions were introduced by this documentary clarification.

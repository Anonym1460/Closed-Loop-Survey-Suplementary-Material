"""Reproduce the contextual lexical audit (Python 3.12, PyMuPDF 1.28.2).
Usage: python reproduce_text_audit.py PATH_TO_SOURCE_PDFS --output AUDIT_DIRECTORY
Source PDFs are not redistributed. Counts describe retained lexical signals, not verified experiments or releases.
"""
from pathlib import Path
import argparse,csv,json,re,unicodedata,hashlib
import pymupdf

def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def write(p,rows,fields):
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
def normalize(t):
    t=unicodedata.normalize('NFKC',t).lower().replace('\u00ad','')
    t=re.sub(r'(?<=\w)-\s*\n\s*(?=\w)','',t)
    t=re.sub(r'[-\u2010-\u2015]',' ',t)
    return re.sub(r'\s+',' ',t)

def context_reason(text,m,pat,rules):
    a,b=m.span()
    if pat=='recall' and re.match(rules['recall_discursive'],text[a:a+100]):return 'discursive_recall'
    if pat=='memory':
        for model in re.finditer(rules['memory_model_name'],text[max(0,a-35):b+10]):
            start=max(0,a-35)
            if start+model.start()<=a and b<=start+model.end():return 'memory_in_model_name'
        if re.match(rules['memory_nonresource'],text[a:a+100]):return 'memory_as_process_or_trigger_attribute'
    if pat=='ram' and re.match(rules['ram_person_name'],text[a:a+100]):return 'ram_in_person_name'
    if pat in ['uci','ucr']:
        token_start=text.rfind(' ',0,a)+1;token_end=text.find(' ',b)
        if token_end<0:token_end=len(text)
        if '@' in text[token_start:token_end]:return 'dataset_acronym_in_email'
    return ''

def run(source_root,output):
    here=Path(__file__).resolve().parent
    corpus=read(here/'supplementary_annotated_corpus.csv');sources={r['record_id']:r for r in read(here/'source_manifest.csv')}
    patterns=json.loads((here/'text_audit_patterns.json').read_text());rules=json.loads((here/'text_audit_context_rules.json').read_text())
    result=[];hits=[];excluded=[]
    for row in corpus:
        source=sources[row['record_id']];available=source['audit_full_text']=='True'
        a={**row,'text_available':available,'audit_included':row['evaluation_modality']!='survey','source_file':source['source_file']}
        text='';handling='not available'
        if available:
            p=source_root/Path(source['source_file'].replace('\\','/'))
            if hashlib.sha256(p.read_bytes()).hexdigest()!=source['sha256']:raise ValueError('Source hash mismatch: '+str(p))
            with pymupdf.open(p) as doc:raw='\n'.join(f'\n[PAGE {n+1}]\n{pg.get_text()}' for n,pg in enumerate(doc))
            headings=[m for m in re.finditer(r'(?im)^\s*(?:(?:[IVX]+|\d+)\.?\s+)?(?:references|bibliography)\s*$',raw) if m.start()>len(raw)*.25]
            if headings:raw=raw[:headings[-1].start()];handling='terminal references heading excluded'
            else:handling='no standalone reference heading detected; residual reference contamination possible'
            text=normalize(raw)
        a['reference_handling']=handling
        for item,terms in patterns.items():
            found=[]
            for pat in terms:
                for match in re.finditer(r'(?<!\w)(?:'+pat+r')(?!\w)',text):
                    reason=context_reason(text,match,pat,rules)
                    entry=dict(record_id=row['record_id'],indicator=item,pattern=pat,offset=match.start(),snippet=text[max(0,match.start()-100):match.end()+140])
                    if reason:
                        if a['audit_included']:excluded.append({**entry,'exclusion_rule':reason})
                    else:
                        found.append(match)
                        if a['audit_included']:hits.append(entry)
            a[item]=bool(found) if available else ''
        a['compute_cost_terms']=a['cpu_memory_terms'];a['code_or_data_release_terms']=(a['code_release_terms'] or a['data_release_terms']) if available else ''
        result.append(a)
    output.mkdir(parents=True,exist_ok=True)
    fields=['record_id','indicator','pattern','offset','snippet']
    write(output/'supplementary_reporting_audit_refined.csv',result,list(result[0]))
    write(output/'text_audit_hits.csv',hits,fields)
    write(output/'text_audit_excluded_hits.csv',excluded,fields+['exclusion_rule'])
    counts={key:sum(r[key] is True and r['audit_included'] for r in result) for key in patterns}
    (output/'audit_counts.json').write_text(json.dumps(counts,indent=2)+'\n')
    print(json.dumps(counts,indent=2))
    return result,hits,excluded
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('sources',type=Path);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();run(args.sources,args.output)

"""Reconcile archived database exports and screening decisions. No new screening is inferred.
Usage: python reproduce_crosscheck.py
"""
from pathlib import Path
import csv,re,unicodedata,json
from collections import Counter
BASE=Path(__file__).resolve().parent
def read(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def norm_title(t):return re.sub(r'[^a-z0-9]','',unicodedata.normalize('NFKD',t).encode('ascii','ignore').decode().lower())
def norm_doi(t):return re.sub(r'^https?://(?:dx\.)?doi.org/','',t.strip().lower())
def key(r):return norm_doi(r['DOI']) or norm_title(r['Title'])
def run():
    raw=BASE/'crosscheck/raw_exports'
    sc=[];ie=[];counts={}
    for p in sorted(raw.glob('*.csv')):
        rr=read(p);counts[p.name]=len(rr)
        if 'Document Title' in rr[0]:
            ie.extend(dict(Title=r['Document Title'],Year=r['Publication Year'],DOI=r['DOI']) for r in rr)
        else:sc.extend(r for r in rr if 1990<=int(r['Year'])<=2025)
    eids={r['EID'] for r in sc};saved=read(BASE/'crosscheck/SCOPUS_UNION_1990_2025_2769.csv')
    assert eids=={r['EID'] for r in saved}
    sk={key(r) for r in sc};ik={key(r) for r in ie}
    master=read(BASE/'crosscheck/preliminary/CROSSCHECK_SCOPUS_IEEE_MASTER_SCREENING_2026-09-16.csv')
    manual=read(BASE/'crosscheck/preliminary/CROSSCHECK_MANUAL_ADJUDICATION_2026-09-16.csv')
    final=read(BASE/'supplementary_screening_decisions_2026-09-16.csv')
    added=[r for r in final if r['assigned_record_id']]
    assert len(final)==25 and all(r['final_action']=='add_to_corpus' for r in final)
    proposals=read(BASE/'crosscheck/preliminary/citation_proposals_not_implemented.csv')
    closure=read(BASE/'crosscheck/preliminary/status_reconciliation_2026-09-23.csv')
    assert len(proposals)==5 and all(r['current_status']=='citation_not_implemented' for r in proposals)
    assert Counter(r['documented_status'] for r in closure)=={'included':17,'citation_not_implemented':2,'historical_no_add_recorded':30,'final_eligibility_not_completed':129}
    assert len(eids)==2769 and len(sk)==2764 and len(ik)==1392
    assert len(sk&ik)==581 and len(sk|ik)==len(master)==3575
    assert len(manual)==105 and len(added)==25
    # A sensitivity rule also joins matching normalized title/year across different DOI-first keys.
    records=saved+ie;parent=list(range(len(records)));seen={}
    def find(i):
        while i!=parent[i]:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for i,r in enumerate(records):
        keys=[('titleyear',norm_title(r['Title']),r['Year'])]
        if norm_doi(r['DOI']):keys.append(('doi',norm_doi(r['DOI'])))
        for k in keys:
            if k in seen:parent[find(i)]=find(seen[k])
            else:seen[k]=i
    result=dict(preliminary_status_reconciliation=dict(Counter(r['documented_status'] for r in closure)),unimplemented_citation_proposals=len(proposals),raw_rows=counts,scopus_filtered_rows=len(sc),scopus_eids=len(eids),scopus_keys=len(sk),ieee_rows=len(ie),ieee_keys=len(ik),shared_keys=len(sk&ik),union_keys=len(sk|ik),title_year_sensitivity_components=len({find(i) for i in range(len(records))}),preliminary_ledger_labels=dict(Counter(r['final_crosscheck_status'] for r in master)),preliminary_manual_labels=dict(Counter(r['decision'] for r in manual)),final_actions=dict(Counter(r['final_action'] for r in final)),addition_roles=dict(Counter(r['final_role'] for r in added)),addition_phases=dict(Counter(r['phase'] for r in added)))
    print(json.dumps(result,indent=2))
    return result
if __name__=='__main__':run()

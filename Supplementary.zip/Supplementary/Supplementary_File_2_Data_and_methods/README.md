# Supplementary material and reproducibility package

This package contains the supplementary material referenced by the revised manuscript and the response to reviewers for manuscript **IOT-D-26-02844**, *Closed-Loop Data Reduction for Edge Time-Series: A Design-Oriented Survey*.

The package has been reduced to submission-relevant material only. Internal revision histories, validation notes, obsolete drafts, LaTeX build files, and other author-side bookkeeping files are intentionally excluded.

## Core supplementary files

- `supplementary_annotated_corpus.csv` — authoritative 128-record annotated corpus. `synthesis_role` separates 107 primary from 21 contextual/secondary records; `evaluation_modality` identifies 14 surveys/tutorials. The legacy CSV field name `loop_objective` is retained for schema compatibility but encodes the primary preservation objective.
- `supplementary_reporting_audit_refined.csv` — record-level lexical reporting audit used in Section 10.1.
- `supplementary_search_templates.txt` — database-specific retrospective coverage-control query templates.
- `supplementary_database_crosscheck_2026-09-16.csv` — query-level database counts, export counts, deduplication notes, and ACM limitation.
- `supplementary_screening_decisions_2026-09-16.csv` — final inclusion log containing the 25 implemented corpus additions. Preliminary candidates and five unimplemented citation proposals are preserved separately under `crosscheck/preliminary/`.
## Companion files submitted separately

The article cites three supplementary files. This ZIP is **Supplementary File 2**, containing the data, methodological records and reproduction scripts. The twelve tables and their bibliography are in **Supplementary File 1**, `Supplementary_File_1_Tables.pdf`. The interactive application is **Supplementary File 3**, `Supplementary_File_3_Configurator.html`; save it locally and open it in a browser. These two companion files are not duplicated inside this archive.

## Lexical-audit reproducibility

- `reproduce_text_audit.py`
- `text_audit_patterns.json`
- `text_audit_hits.csv` — retained matches.
- `text_audit_context_rules.json` — deterministic exclusions of observed non-indicator usages.
- `text_audit_excluded_hits.csv` — rejected candidate matches and rule identifiers.
- `text_audit_validation_cases.csv` — targeted regression cases, not an independent or random validation sample.
- `audit_counts.json` — non-survey record counts.
- `source_manifest.csv`

The audit uses Python 3.12 and PyMuPDF 1.28.2. Source PDFs are **not redistributed**. To rerun the audit, obtain the source papers separately and preserve the relative paths in `source_manifest.csv`:

```sh
python reproduce_text_audit.py PATH_TO_EXTRACTED_SOURCE_PDFS --output AUDIT_DIRECTORY
```

The script verifies SHA-256 hashes of available source PDFs. The audit measures lexical visibility, not study quality, confirmed baseline use, or verified code/data release. Three non-survey records lack the exact searchable full text used by the local audit; therefore the manuscript reports both the 114-record non-survey denominator and the 111-record available-text denominator. No independent inter-rater statistic was calculated.

## Database-cross-check reproducibility

- `reproduce_crosscheck.py`
- `crosscheck/raw_exports/` — archived Scopus and IEEE Xplore exports used by the reconciliation script.
- `crosscheck/SCOPUS_UNION_1990_2025_2769.csv` — saved 2,769-EID Scopus union.
- `crosscheck/preliminary/CROSSCHECK_SCOPUS_IEEE_MASTER_SCREENING_2026-09-16.csv` — 3,575-key archived preliminary triage ledger; its legacy status labels are not final full-text eligibility decisions.
- `crosscheck/preliminary/CROSSCHECK_MANUAL_ADJUDICATION_2026-09-16.csv` — 105 records reviewed for priority or possible eligibility; final eligibility was not completed for all candidates.
- `crosscheck/reconciliation.json` — saved reconciliation summary.

Run:

```sh
python reproduce_crosscheck.py
```

The script reproduces the reported database reconciliation from the archived exports and ledgers: 2,769 Scopus EIDs / 2,764 DOI-first keys, 1,392 IEEE keys, 581 shared keys, and a 3,575-key union; a DOI-or-title/year sensitivity yields 3,562 components. The historical manual-ledger labels `primary_add_candidate` and `contextual_add_candidate` are prioritization labels, not automatic inclusion decisions. Final inclusion is recorded in `supplementary_screening_decisions_2026-09-16.csv`. The preliminary README and status reconciliation explicitly distinguish implemented inclusions, historical no-add decisions, unimplemented citation proposals, and 129 candidates without completed final eligibility assessment. Those 129 are not treated as scientific exclusions. No retrieval-recall or exhaustive-screening claim is made.

The original historical triage scoring code/weights and the complete targeted-query history were not recovered; the supplied material reproduces counts and saved decisions, not the historical ranking algorithm. The ACM Digital Library query returned 158 displayed hits, but bulk export/year filtering were unavailable, so no ACM record-level screening is claimed.

## Preliminary records and scope of the close-out

See `crosscheck/preliminary/README.md` for the documentary reconciliation, the preserved original candidate log, and the status of the five citation proposals that were not implemented. The 128-record corpus remains unchanged. The lexical audit was corrected on 24 September 2026 as described below.

The legacy query-log column `deduplicated_or_eligible_records` reports database filtering/deduplication counts, not final scientific eligibility. The UNION row is the preliminary triage universe.

## Context corrections to the lexical audit (24 September 2026)

The audit excludes discursive uses of recall, memory within long short-term memory model names, memory-based event-triggering and process-memory phrases, Ram followed by an author initial and surname, and UCI/UCR inside email tokens. The exact expressions are in text_audit_context_rules.json; the data-availability expressions also recognize explicit code-and-data availability statements. These are targeted deterministic exclusions, not a comprehensive semantic classifier. Valid constant-memory, cache-memory, metric recall and dataset mentions remain eligible. No record-specific flag overrides are used.

Across the 111 available non-survey texts, the corrected counts are energy 61, latency 40, CPU/memory/runtime 71, throughput 28, public-data 31, simple-policy 23, task/event 30, code availability 13 and data availability 1. The corresponding 114-record fractions include three missing texts in the denominator but do not code missing texts as negative observations. The data-availability hit is R095; third-party dataset mentions and ambiguous code/data/artifact boilerplate do not by themselves establish author data release. The audit does not verify downloadability, ownership or reproducibility of a release.

The regression cases deliberately exercise known errors and retained positive examples. They do not estimate sensitivity/specificity, provide independent manual annotation, or justify inter-rater agreement statistics. Ambiguous remaining matches, residual references, extraction errors and unlisted phrase variants can still affect counts. The corpus selection, evidence labels, historical search records and inclusion decisions are not changed by this lexical correction.

## Inclusion phase versus discovery source

In supplementary_screening_decisions_2026-09-16.csv, phase is the recorded incorporation phase (8 retrospective_crosscheck; 17 targeted_2024_2026_update). It is not a mutually exclusive discovery-source classification. The separate discovered_via field records Scopus/IEEE for 17 additions: the eight cross-check-phase records plus R114, R116, R118, R119, R120, R122, R123, R124 and R125 in the targeted-update phase. This agrees with the preliminary reconciliation (16 included from the manual set plus one from the deferred set). The other eight additions have targeted-search discovery provenance. Each of the 25 additions is counted once.

## Targeted record correction

annotation_corrections.csv and annotation_corrections.md document the full-text correction of R002: theoretical evidence with an illustrative simulation, and no specified IoT execution layer. All 128 records remain; the R002 correction does not change its lexical-audit flags; the evidence/layer distributions and derived metadata are synchronized.

## Canonical source filenames and recovered full texts

The distributed source_manifest.csv and audit CSV use R001.pdf through R128.pdf rather than author-machine filenames. Hashes identify the exact source versions. The 122 previously available source hashes remain unchanged; publisher texts for R049, R100 and R103 were additionally matched by title/authors/year/DOI and hashed. The audit now has 125 total source PDFs, including 14 surveys, hence 111 available non-survey texts. Only R001, R003 and R057 remain unavailable. Source PDFs are not distributed.

To prepare an independently obtained local collection, run:

```sh
python prepare_audit_sources.py SOURCE_DIRECTORY --output CANONICAL_DIRECTORY
python reproduce_text_audit.py CANONICAL_DIRECTORY --output AUDIT_DIRECTORY
```

The preparation script searches recursively and matches hashes; it copies matching files under record-ID names without renaming originals or overwriting a different existing file. Multiple source directories may be supplied. It reports unmatched required versions explicitly. The source root used for rerunning the audit must contain the canonical filenames. No paths from the author machine or private filename mapping are distributed.


## Contained revision, 25 September 2026

The corpus still contains 128 records (107 primary, 21 contextual); the lexical audit and its 111/114 text coverage are unchanged. Targeted source checks classify R007 and R023 as theoretical under the dominant-contribution convention already applied to R002. Evidence totals are empirical 81, theoretical 10, survey 14, benchmark 10, simulation 9, and trace replay 4. Current corpus and audit-metadata rows, manuscript appendix, and supplementary distributions are synchronized. This does not claim complete independent reannotation.

Supplementary Tables S1-S6 hold chronology, operational protocol, file inventory, corpus profile, general survey comparison, and lexical patterns. S7-S8 retain collection provenance; S9-S12 provide detailed distributions. Supplementary bibliography numbering is independent of the manuscript. R003's corpus title now separates work title from venue. The CAMEO DOI is supplied in the editable bibliography.

The configurator retains every ranking weight. A visible notice requires objective-specific verification, and every metric profile includes reduction/resource saving relative to the unreduced stream. Scores remain heuristic candidate support, not guaranteed compatibility or expected performance. No new user study or exhaustive candidate screening was performed.


## Final package refinements

The historical Scopus analysis uses the archived 2,769-EID union. Its exported records and all nine lexical-audit counts are unchanged. The broad search template supports reruns; archived export-group counts are distinct from any later search-interface result count. Exact executed C1-C6 strings are not fully preserved.

The configurator now issues a contextual warning when SoD or prediction leads an event/task profile. No ranking weights were changed. The manuscript presents available-text lexical percentages first and retains corpus-normalized values as a secondary column.

Schema equivalence: `open/background` in `loop_objective_final` of the final-inclusion log corresponds to `open` in the annotated corpus. The historical inclusion log is preserved. Neither label is a fifth preservation objective.

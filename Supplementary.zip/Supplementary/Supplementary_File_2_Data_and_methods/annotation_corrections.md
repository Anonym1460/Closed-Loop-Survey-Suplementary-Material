# Targeted annotation corrections

## Historical R002 correction (24 September 2026)

The six-page publisher copy confirms the theoretical analysis and illustrative simulation. R002 remains a primary, quality-controlled study. The single-valued evidence label records the dominant theoretical contribution; this does not deny the simulation. Its IoT execution layer is not specified. The correction changes empirical 84 to 83, theoretical 7 to 8, sensor-network 26 to 25, and not-specified 1 to 2. Other labels, membership and lexical indicators are unchanged.

The mention of execution time on PDF p. 2 is retained as computational-cost language, not as a measured hardware result. No corpus-wide reannotation or independent agreement assessment is implied.

The newly checked publisher PDF has SHA-256 907a7bda90e8cb188d2d129e12860e9368e02f329ba45f5faa010b056cd314c3. Its six page texts, extracted with PyMuPDF 1.28.2, are identical to the archived audit copy whose SHA-256 is c5192459e7262fb4f3cf2dd513bf66d7e8a38ffc416f59c603c566bdc43afbf9. The established audit-source hash is retained; the distributed manifest uses a canonical record-ID filename. Source PDFs are not redistributed.


## Contained revision, 25 September 2026

R007 and R023: evaluation modality corrected from empirical to theoretical after checking the source texts. The dominant contribution is analytical; the simulation in Tabuada is illustrative, using the same criterion as R002. Empirical/theoretical totals are now 81/10. All other evidence counts, membership, preservation labels, and lexical audit flags are unchanged. R003: workshop venue removed from the corpus title; the bibliography already separates it. These are targeted corrections, not a complete independent recoding of all evidence labels.
